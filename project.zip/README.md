# Photo MCQ Quiz — Android Studio project

## Features
- Pick a page photo from the phone.
- On-device OCR using Google ML Kit.
- Ask Gemini to create Hindi MCQs with four plausible, similar distractors.
- Instant right/wrong feedback, explanation, score.
- Select 25, 50, or 100 questions.

## Build APK
1. Install Android Studio (latest stable) on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync and download dependencies.
4. Get a Gemini API key from Google AI Studio.
5. Run on a phone, enter the key in the app, choose a photo, and generate a quiz.
6. To build APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK output: app/build/outputs/apk/debug/app-debug.apk

## Important
- This is a starter source project, not a precompiled APK.
- Internet is needed for Gemini question generation; OCR runs on-device.
- The API key is entered by the user and is not embedded in the source. For a public production app, use a secure backend rather than shipping a shared API key in the APK.
- AI can make mistakes. Verify important answer keys against the source book.
- Gemini model/API availability can change; if the configured model is unavailable, update the model name in MainActivity.kt to a currently supported Gemini model.
