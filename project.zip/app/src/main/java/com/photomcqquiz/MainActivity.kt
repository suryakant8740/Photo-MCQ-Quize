package com.photomcqquiz

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class QuizQuestion(val question: String, val options: List<String>, val answer: Int, val explanation: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { QuizScreen() } }
    }
}

@Composable
fun QuizScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var apiKey by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("किताब की फोटो चुनें और AI API key डालें।") }
    var count by remember { mutableIntStateOf(100) }
    var questions by remember { mutableStateOf(listOf<QuizQuestion>()) }
    var index by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        imageUri = uri
        status = if (uri != null) "फोटो चुनी गई। अब प्रश्न बनाएं।" else "फोटो नहीं चुनी गई।"
        questions = emptyList()
    }

    fun answerOption(opt: Int) {
        if (selected == null && questions.isNotEmpty()) {
            selected = opt
            if (opt == questions[index].answer) score++
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Photo MCQ Quiz", style = MaterialTheme.typography.headlineMedium)
        Text("किताब की फोटो से परीक्षा जैसे MCQ बनाएं", style = MaterialTheme.typography.bodyLarge)
        OutlinedTextField(apiKey, { apiKey = it }, label = { Text("Gemini API key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Text("API key Google AI Studio से लें। इसे किसी के साथ साझा न करें।")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { picker.launch("image/*") }) { Text("फोटो चुनें") }
            Text(if (imageUri == null) "कोई फोटो नहीं" else "फोटो तैयार")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("प्रश्नों की संख्या:")
            listOf(25, 50, 100).forEach { n ->
                FilterChip(selected = count == n, onClick = { count = n }, label = { Text("$n") })
            }
        }
        Button(
            enabled = imageUri != null && apiKey.isNotBlank(),
            onClick = {
                scope.launch {
                    try {
                        status = "फोटो पढ़ी जा रही है..."
                        val image = InputImage.fromFilePath(context, imageUri!!)
                        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                        val extracted = recognizer.process(image).await().text
                        if (extracted.isBlank()) throw Exception("फोटो से टेक्स्ट नहीं पढ़ा गया। साफ फोटो लें।")
                        status = "AI विकल्प और उत्तर तैयार कर रहा है..."
                        val result = withContext(Dispatchers.IO) { generateQuestions(apiKey.trim(), extracted, count) }
                        questions = result
                        index = 0; selected = null; score = 0; finished = false
                        status = "${result.size} प्रश्न तैयार हैं। उत्तर चुनते ही सही/गलत दिखेगा।"
                    } catch (e: Exception) {
                        status = "त्रुटि: ${e.message ?: "प्रश्न नहीं बन सके"}"
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("MCQ सेट बनाएं") }
        Text(status, color = MaterialTheme.colorScheme.primary)
        if (questions.isNotEmpty() && !finished) {
            val q = questions[index]
            LinearProgressIndicator(progress = { (index + if (selected != null) 1 else 0).toFloat() / questions.size }, modifier = Modifier.fillMaxWidth())
            Text("प्रश्न ${index + 1}/${questions.size}", style = MaterialTheme.typography.titleMedium)
            Text(q.question, style = MaterialTheme.typography.titleLarge)
            q.options.forEachIndexed { i, option ->
                val isCorrect = selected != null && i == q.answer
                val isWrong = selected == i && i != q.answer
                val container = when {
                    isCorrect -> MaterialTheme.colorScheme.primaryContainer
                    isWrong -> MaterialTheme.colorScheme.errorContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                Surface(color = container, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RadioButton(selected == i, onClick = { answerOption(i) }, enabled = selected == null)
                        Text("${'A' + i}. $option", modifier = Modifier.weight(1f).padding(top = 10.dp))
                    }
                }
            }
            if (selected != null) {
                Text(if (selected == q.answer) "✓ सही उत्तर!" else "✗ गलत उत्तर। सही जवाब: ${'A' + q.answer}. ${q.options[q.answer]}",
                    color = if (selected == q.answer) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.titleMedium)
                if (q.explanation.isNotBlank()) Text("व्याख्या: ${q.explanation}")
                Button(onClick = {
                    if (index == questions.lastIndex) finished = true
                    else { index++; selected = null }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (index == questions.lastIndex) "रिजल्ट देखें" else "अगला प्रश्न") }
            }
        }
        if (finished) {
            Text("टेस्ट पूरा हुआ", style = MaterialTheme.typography.headlineSmall)
            Text("आपका स्कोर: $score / ${questions.size}", style = MaterialTheme.typography.headlineMedium)
            Button(onClick = { questions = emptyList(); finished = false; status = "नई फोटो चुनें।" }) { Text("नया सेट बनाएं") }
        }
        Text("नोट: AI द्वारा बनाए गए उत्तरों को परीक्षा/पढ़ाई में उपयोग करने से पहले किताब से मिलान कर लें। कठिन या अस्पष्ट प्रश्न AI गलत बना सकता है।")
    }
}

private fun generateQuestions(key: String, source: String, count: Int): List<QuizQuestion> {
    val prompt = """
आप भारत की प्रतियोगी परीक्षाओं के अनुभवी हिंदी प्रश्न-निर्माता हैं।
नीचे दिए स्रोत-पाठ के आधार पर अधिकतम $count MCQ बनाएं।
नियम:
- केवल स्रोत में समर्थित तथ्यों से प्रश्न बनाएं; बाहर की जानकारी जोड़कर तथ्य न गढ़ें।
- हर प्रश्न के ठीक 4 विकल्प हों और केवल एक निर्विवाद सही उत्तर हो।
- गलत विकल्प plausible और आपस में मिलते-जुलते हों: समान श्रेणी, समान प्रकार के नाम/तारीख/वर्ष/स्थान। हास्यास्पद या स्पष्ट रूप से गलत विकल्प न दें।
- विकल्पों की लंबाई लगभग समान रखें। सही विकल्प की स्थिति A/B/C/D में बदलते रहें।
- यदि स्रोत में पर्याप्त सामग्री न हो तो कम प्रश्न बनाएं; संख्या पूरी करने के लिए प्रश्न न गढ़ें।
- प्रत्येक उत्तर और छोटी व्याख्या की पुष्टि करें। अनिश्चित प्रश्न छोड़ दें।
केवल वैध JSON लौटाएं: {"questions":[{"question":"...","options":["...","...","...","..."],"answer":0,"explanation":"..."}]}
स्रोत-पाठ:
$source
""".trimIndent()

    val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
        .put("generationConfig", JSONObject().put("temperature", 0.2).put("responseMimeType", "application/json"))
    val client = OkHttpClient.Builder().callTimeout(120, TimeUnit.SECONDS).build()
    val request = Request.Builder()
        .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key")
        .post(body.toString().toRequestBody("application/json".toMediaType()))
        .build()
    client.newCall(request).execute().use { response ->
        val raw = response.body?.string() ?: ""
        if (!response.isSuccessful) throw Exception("AI सेवा ने ${response.code} त्रुटि दी। API key और इंटरनेट जाँचें।")
        val text = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val arr = JSONObject(text).getJSONArray("questions")
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val opts = o.getJSONArray("options")
            if (opts.length() != 4) return@mapNotNull null
            val options = (0..3).map { opts.getString(it) }
            val answer = o.getInt("answer")
            if (answer !in 0..3) return@mapNotNull null
            QuizQuestion(o.getString("question"), options, answer, o.optString("explanation", ""))
        }
    }
}
