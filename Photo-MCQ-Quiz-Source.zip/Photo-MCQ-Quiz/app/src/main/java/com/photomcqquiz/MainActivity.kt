package com.photomcqquiz
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class MainActivity: ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaterialTheme { Screen() } } }
}
data class Q(val question:String,val options:List<String>,val answer:Int,val explain:String)
@Composable fun Screen() {
 val ctx= LocalContext.current; val scope= rememberCoroutineScope()
 var key by remember { mutableStateOf("") }; var text by remember { mutableStateOf("") }
 var status by remember { mutableStateOf("किताब के पेज की फोटो चुनें।") }
 var qs by remember { mutableStateOf(listOf<Q>()) }; var idx by remember { mutableIntStateOf(0) }
 var score by remember { mutableIntStateOf(0) }; var chosen by remember { mutableIntStateOf(-1) }; var amount by remember { mutableIntStateOf(10) }
 val picker= rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri:Uri? ->
  if(uri!=null) scope.launch {
   status="फोटो पढ़ी जा रही है..."
   try {
    val bmp=withContext(Dispatchers.IO){ ctx.contentResolver.openInputStream(uri).use { android.graphics.BitmapFactory.decodeStream(it) } }
    val img=InputImage.fromBitmap(bmp,0)
    val hi=TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()).process(img).await()
    val en=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img).await()
    text=listOf(hi.text,en.text).filter{it.isNotBlank()}.joinToString("\\n")
    status=if(text.isBlank()) "टेक्स्ट नहीं पढ़ा गया। साफ फोटो चुनें।" else "फोटो पढ़ ली गई।"
   } catch(e:Exception){ status="फोटो पढ़ने में समस्या: ${e.message}" }
  }
 }
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
  Text("Photo MCQ Quiz",style=MaterialTheme.typography.headlineMedium)
  OutlinedTextField(key,{key=it},label={Text("Gemini API Key")},modifier=Modifier.fillMaxWidth())
  Button(onClick={picker.launch("image/*")},modifier=Modifier.fillMaxWidth()){Text("फोटो चुनें")}
  Text(status)
  if(text.isNotBlank()){
   Text("पढ़ा गया टेक्स्ट"); Text(text.take(2000))
   Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){ listOf(10,25,50).forEach { n-> FilterChip(amount==n,{amount=n},label={Text("$n प्रश्न")}) } }
   Button(enabled=key.isNotBlank(),onClick={
    status="MCQ बन रहे हैं..."
    scope.launch { try { qs=makeQs(key,text,amount); idx=0;score=0;chosen=-1;status="${qs.size} प्रश्न तैयार हैं" } catch(e:Exception){status="त्रुटि: ${e.message}"} }
   },modifier=Modifier.fillMaxWidth()){Text("MCQ बनाएं")}
  }
  if(qs.isNotEmpty() && idx<qs.size){
   val q=qs[idx]; Text("प्रश्न ${idx+1}/${qs.size}"); Text(q.question,style=MaterialTheme.typography.titleLarge)
   q.options.forEachIndexed { i,s-> OutlinedButton(onClick={if(chosen<0){chosen=i;if(i==q.answer)score++}},enabled=chosen<0,modifier=Modifier.fillMaxWidth()){Text("${'A'+i}. $s")} }
   if(chosen>=0){Text(if(chosen==q.answer)"सही जवाब!" else "गलत। सही उत्तर: ${q.options[q.answer]}"); Text(q.explain); Button(onClick={idx++;chosen=-1}){Text("अगला प्रश्न")} }
  } else if(qs.isNotEmpty() && idx>=qs.size) { Text("टेस्ट पूरा! स्कोर: $score / ${qs.size}"); Button(onClick={idx=0;score=0;chosen=-1}){Text("दोबारा टेस्ट")} }
  Text("Gemini API key अलग से चाहिए; ChatGPT subscription में Gemini API शामिल नहीं है।",style=MaterialTheme.typography.bodySmall)
 }
}
suspend fun com.google.android.gms.tasks.Task<Text>.await():Text=suspendCancellableCoroutine { c-> addOnSuccessListener{if(c.isActive)c.resume(it)}; addOnFailureListener{if(c.isActive)c.resumeWith(Result.failure(it))} }
suspend fun makeQs(key:String,src:String,n:Int):List<Q> = withContext(Dispatchers.IO) {
 val prompt="दिए गए पाठ से ठीक $n हिंदी MCQ बनाओ। हर प्रश्न के 4 विश्वसनीय मिलते-जुलते विकल्प हों। केवल JSON array दो। प्रत्येक item: question, options (4 strings), answer (0-3), explain. पाठ:\\n$src"
 val body=JSONObject().put("contents",JSONArray().put(JSONObject().put("parts",JSONArray().put(JSONObject().put("text",prompt)))))
 val req=Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key").post(body.toString().toRequestBody("application/json".toMediaType())).build()
 OkHttpClient().newCall(req).execute().use { r->
  val raw=r.body?.string().orEmpty(); if(!r.isSuccessful) error("API ${r.code}: $raw")
  val out=JSONObject(raw).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
  val arr=JSONArray(out.substring(out.indexOf('['),out.lastIndexOf(']')+1))
  (0 until arr.length()).map { i-> val o=arr.getJSONObject(i); val a=o.getJSONArray("options"); Q(o.getString("question"),(0 until a.length()).map{a.getString(it)},o.getInt("answer"),o.optString("explain")) }
 }
}
