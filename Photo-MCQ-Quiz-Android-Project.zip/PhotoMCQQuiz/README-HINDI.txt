PHOTO MCQ QUIZ - Android app source

Features:
- Book page photos (up to 5) or pasted text/questions.
- Generate 1 to 100 Hindi MCQs with four options using Gemini AI.
- Answer questions, submit, see score and correct answers.

IMPORTANT:
- App needs internet and a Gemini API key. Enter the key inside the app; do not put it in GitHub or share it.
- AI-generated questions/answers may contain mistakes. Verify important answers with the book.
- This workflow creates a DEBUG APK for testing/sideloading, not a Play Store release.

Build:
Upload all project files to a GitHub repository, preserving .github/workflows/build-apk.yml.
Open Actions > Build Photo MCQ Quiz APK > Run workflow.
Download artifact Photo-MCQ-Quiz-APK and extract app-debug.apk.
