package com.photomcqquiz

import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class MCQ(val question: String, val options: List<String>, val answer: Int, val explanation: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuizApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var apiKey by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var count by remember { mutableStateOf("100") }
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var questions by remember { mutableStateOf<List<MCQ>>(emptyList()) }
    var selected by remember { mutableStateOf<Map<Int, Int>>(emptyMap()) }
    var submitted by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("किताब की फोटो चुनें या प्रश्न पेस्ट करें।") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { images = it.take(5) }
    val score = questions.indices.count { selected[it] == questions[it].answer }

    Scaffold(topBar = { TopAppBar(title = { Text("Photo MCQ Quiz") }) }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("किताब से अपना पेपर बनाएं", style = MaterialTheme.typography.titleLarge) }
            item {
                OutlinedTextField(apiKey, { apiKey = it }, label = { Text("Gemini API Key") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                Text("API Key Google AI Studio से लें। इसे किसी के साथ साझा न करें।", style = MaterialTheme.typography.bodySmall)
            }
            item { OutlinedTextField(text, { text = it }, label = { Text("किताब के प्रश्न/टेक्स्ट (वैकल्पिक)") }, modifier = Modifier.fillMaxWidth(), minLines = 4) }
            item { OutlinedTextField(count, { count = it.filter(Char::isDigit).take(3) }, label = { Text("प्रश्नों की संख्या (1–100)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item {
                OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("किताब के पेज की फोटो चुनें") }
                Text("चुनी गई फोटो: ${images.size} (अधिकतम 5)")
            }
            item {
                Button(onClick = {
                    val n = count.toIntOrNull()?.coerceIn(1, 100) ?: 100
                    when {
                        apiKey.isBlank() -> status = "पहले Gemini API Key डालें।"
                        text.isBlank() && images.isEmpty() -> status = "फोटो चुनें या प्रश्न लिखें।"
                        else -> {
                            busy = true; status = "पेपर बनाया जा रहा है…"; questions = emptyList(); selected = emptyMap(); submitted = false
                            scope.launch {
                                try { questions = makePaper(apiKey, text, images, n, context); status = "${questions.size} प्रश्न तैयार हैं।" }
                                catch (e: Exception) { status = "त्रुटि: ${e.message ?: "नेटवर्क/API Key जांचें"}" }
                                finally { busy = false }
                            }
                        }
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "प्रतीक्षा करें…" else "पेपर बनाएं") }
                Text(status)
            }
            if (questions.isNotEmpty()) {
                item { HorizontalDivider(); Text("MCQ पेपर — अंक: $score / ${questions.size}", style = MaterialTheme.typography.titleLarge) }
                itemsIndexed(questions) { i, q ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${i + 1}. ${q.question}", style = MaterialTheme.typography.titleMedium)
                            q.options.forEachIndexed { j, option ->
                                Row {
                                    RadioButton(selected = selected[i] == j, enabled = !submitted, onClick = { selected = selected + (i to j) })
                                    Text(option, Modifier.padding(top = 12.dp))
                                }
                            }
                            if (submitted) {
                                Text(if (selected[i] == q.answer) "✓ सही जवाब" else "✗ सही उत्तर: ${q.options[q.answer]}", color = if (selected[i] == q.answer) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                if (q.explanation.isNotBlank()) Text(q.explanation)
                            }
                        }
                    }
                }
                item {
                    Button(onClick = { submitted = true }, enabled = !submitted, modifier = Modifier.fillMaxWidth()) { Text("पेपर जमा करें") }
                    OutlinedButton(onClick = { selected = emptyMap(); submitted = false }, modifier = Modifier.fillMaxWidth()) { Text("फिर से हल करें") }
                }
            }
        }
    }
}

private suspend fun makePaper(key: String, source: String, uris: List<Uri>, count: Int, context: android.content.Context): List<MCQ> = withContext(Dispatchers.IO) {
    val parts = JSONArray()
    parts.put(JSONObject().put("text", "किताब के दिए गए पाठ/फोटो से हिंदी में $count नए MCQ बनाओ। हर प्रश्न के 4 विकल्प हों। answer सही विकल्प का 0 से शुरू index हो। तथ्य किताब के बाहर से न जोड़ो, दोहराव न हो। केवल JSON array दो। हर item: {\"question\":\"...\",\"options\":[\"...\",\"...\",\"...\",\"...\"],\"answer\":0,\"explanation\":\"...\"}. पाठ: $source"))
    uris.forEach { uri ->
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@forEach
        val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
        parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))))
    }
    val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts))).put("generationConfig", JSONObject().put("temperature", 0.4).put("responseMimeType", "application/json"))
    val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key").post(body.toString().toRequestBody("application/json".toMediaType())).build()
    val response = OkHttpClient().newCall(req).execute()
    val responseBody = response.body?.string().orEmpty()
    if (!response.isSuccessful) throw IllegalStateException("API error ${response.code}: $responseBody")
    val raw = JSONObject(responseBody).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    val arr = JSONArray(raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
    (0 until arr.length()).mapNotNull { i ->
        val o = arr.getJSONObject(i); val a = o.getJSONArray("options")
        if (a.length() != 4) null else {
            val answer = o.optInt("answer", -1)
            if (answer !in 0..3) null else MCQ(o.optString("question"), (0..3).map { a.getString(it) }, answer, o.optString("explanation"))
        }
    }.take(count)
}
