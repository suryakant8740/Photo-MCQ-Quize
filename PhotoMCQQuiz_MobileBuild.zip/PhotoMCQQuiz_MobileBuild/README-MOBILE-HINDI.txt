Photo MCQ Quiz - मोबाइल से APK बनाने की सरल विधि

इस ZIP में Android Studio source project और GitHub Actions build workflow है। यह APK पहले से बनी हुई नहीं है।

मोबाइल से APK बनाने के लिए:
1. GitHub अकाउंट में लॉगिन करें और New repository बनाएं। नाम: Photo-MCQ-Quiz
2. Repository में Add file > Upload files चुनें।
3. इस पैकेज के अंदर की project.zip और .github/workflows/build-apk.yml फाइलें अपलोड करें।
   ध्यान दें: workflow फाइल का रास्ता बिल्कुल .github/workflows/build-apk.yml होना चाहिए।
4. Commit changes करें।
5. Repository के Actions टैब में जाएँ। Build Photo MCQ Quiz APK workflow खोलें।
6. यदि अपने आप शुरू न हो तो Run workflow दबाएँ।
7. Build सफल होने पर उसी run के नीचे Artifacts में Photo-MCQ-Quiz-APK डाउनलोड करें।
8. ZIP खोलकर app-debug.apk निकालें और उस पर टैप करके इंस्टॉल करें। Android पूछे तो इस स्रोत से इंस्टॉल की अनुमति दें।

ध्यान दें:
- GitHub पर लॉगिन और इंटरनेट जरूरी है।
- APK debug/test build है, Play Store release नहीं।
- ऐप के वर्तमान source code में Gemini API key खुद डालनी पड़ती है।
- मौजूदा OCR मॉड्यूल ML Kit Latin recognizer इस्तेमाल करता है; हिंदी देवनागरी किताबों पर इसकी पहचान कमजोर हो सकती है। इसे भरोसेमंद हिंदी OCR और Gemini image input के लिए आगे सुधारना होगा।
- अपनी API key सार्वजनिक GitHub repository में कभी न डालें।
